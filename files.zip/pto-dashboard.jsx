import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { Settings2, Plus, Trash2, Clock3, Download, Upload } from "lucide-react";

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------
const COLOR = {
  bg: "#0E141B",
  surface: "#161F2A",
  surfaceRaised: "#1C2733",
  rule: "#2A3542",
  ruleFaint: "#1F2933",
  gold: "#C9A227",
  goldDim: "#8B7220",
  goldSoft: "rgba(201,162,39,0.12)",
  textPrimary: "#E7EAEE",
  textMuted: "#8996A6",
  textFaint: "#5B6675",
  positive: "#5FAE7F",
  negative: "#C1554B",
};

const FONT_DISPLAY = "'Oswald', 'Bebas Neue', 'Arial Narrow', sans-serif";
const FONT_MONO = "'JetBrains Mono', 'Roboto Mono', ui-monospace, monospace";
const FONT_BODY = "'Inter', system-ui, -apple-system, sans-serif";

const DEFAULT_SETTINGS = {
  startingBalance: 161.55,
  accrualRate: 10.77,
  lastPaycheckDate: "2026-07-30",
  historyStartDate: "2026-01-01",
  payFrequencyDays: 14,
  annualUsagePlan: 200,
  planStartYear: 2027,
  projectionEndDate: "2029-12-15",
  workDayHours: 8,
  ptoCap: 420,
  rotationAnchorDate: "2026-01-01", // a known first day of a 5-on block
  rotationOn1: 5,
  rotationOff1: 2,
  rotationOn2: 5,
  rotationOff2: 3,
};

// ---------------------------------------------------------------------------
// Date helpers (all dates treated as UTC midnight to avoid TZ drift)
// ---------------------------------------------------------------------------
const toUTC = (isoDateStr) => new Date(isoDateStr + "T00:00:00Z");
const addDaysUTC = (date, days) => new Date(date.getTime() + days * 86400000);
const fmtISO = (date) => date.toISOString().slice(0, 10);
const fmtShort = (date) =>
  date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" });
const fmtChip = (date) =>
  date.toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });

// Rotating shift schedule: repeating cycle of onDays1 on, offDays1 off,
// onDays2 on, offDays2 off (e.g. 5-on/2-off/5-on/3-off), anchored to a known
// first day of an "on" block. Returns true if the given date is a scheduled
// work day under that rotation.
function isRotationWorkDay(date, settings) {
  const cycle = settings.rotationOn1 + settings.rotationOff1 + settings.rotationOn2 + settings.rotationOff2;
  if (!cycle) return true;
  const anchor = toUTC(settings.rotationAnchorDate);
  const diffDays = Math.round((date.getTime() - anchor.getTime()) / 86400000);
  const offset = ((diffDays % cycle) + cycle) % cycle;
  const b1 = settings.rotationOn1;
  const b2 = b1 + settings.rotationOff1;
  const b3 = b2 + settings.rotationOn2;
  if (offset < b1) return true;
  if (offset < b2) return false;
  if (offset < b3) return true;
  return false;
}

function buildPayPeriods(settings) {
  const start = toUTC(settings.lastPaycheckDate);
  const end = toUTC(settings.projectionEndDate);
  const periods = [];
  let d = start;
  while (d.getTime() <= end.getTime()) {
    periods.push(d);
    d = addDaysUTC(d, settings.payFrequencyDays);
  }
  return periods; // includes the lastPaycheckDate itself as period 0 (no accrual applied there)
}

// Pay periods stepping BACKWARD from the anchor (last paycheck date) down to
// (but not before) the history start date. Returned in ascending order,
// oldest first, and does not include the anchor date itself.
function buildHistoryPeriods(settings) {
  const anchor = toUTC(settings.lastPaycheckDate);
  const histStart = toUTC(settings.historyStartDate);
  const periods = [];
  let d = addDaysUTC(anchor, -settings.payFrequencyDays);
  while (d.getTime() >= histStart.getTime()) {
    periods.unshift(d);
    d = addDaysUTC(d, -settings.payFrequencyDays);
  }
  return periods;
}

function buildRateSchedule(settings, rateChanges) {
  const base = { date: toUTC(settings.lastPaycheckDate), rate: settings.accrualRate };
  const changes = [...rateChanges]
    .filter((r) => r.effectiveDate && !isNaN(Number(r.rate)))
    .map((r) => ({ date: toUTC(r.effectiveDate), rate: Number(r.rate) }))
    .filter((r) => r.date.getTime() >= base.date.getTime())
    .sort((a, b) => a.date.getTime() - b.date.getTime());
  return [base, ...changes];
}

function rateAt(schedule, date) {
  let rate = schedule[0].rate;
  for (const step of schedule) {
    if (step.date.getTime() <= date.getTime()) rate = step.rate;
    else break;
  }
  return rate;
}

// ---------------------------------------------------------------------------
// Core projection engine
// ---------------------------------------------------------------------------
function useProjection(settings, entries, rateChanges, today) {
  return useMemo(() => {
    const periods = buildPayPeriods(settings);
    const future = periods.filter((p) => p.getTime() > toUTC(settings.lastPaycheckDate).getTime());
    const schedule = buildRateSchedule(settings, rateChanges);

    const periodsPerYear = {};
    future.forEach((p) => {
      const y = p.getUTCFullYear();
      periodsPerYear[y] = (periodsPerYear[y] || 0) + 1;
    });

    const sortedEntries = [...entries].sort((a, b) => (a.date < b.date ? -1 : 1));
    const usageOnOrBefore = (dateObj) =>
      sortedEntries
        .filter((e) => toUTC(e.date).getTime() <= dateObj.getTime())
        .reduce((sum, e) => sum + Number(e.hours || 0), 0);
    const usageInWindow = (fromExclusive, toInclusive) =>
      sortedEntries
        .filter((e) => {
          const t = toUTC(e.date).getTime();
          return t > fromExclusive.getTime() && t <= toInclusive.getTime();
        })
        .reduce((sum, e) => sum + Number(e.hours || 0), 0);

    const todayTime = today.getTime();
    const chartData = [];
    const anchorDate = toUTC(settings.lastPaycheckDate);
    const anchorBalance = Math.min(settings.startingBalance, settings.ptoCap);

    // ---- reconstruct history (historyStartDate -> lastPaycheckDate) ----
    // Walk backward from the known anchor balance, undoing each period's
    // accrual and adding back any usage logged in that period's window.
    // Assumes the PTO cap wasn't hit before the anchor (a reasonable
    // assumption since the anchor balance is normally well under the cap).
    const historyPeriods = buildHistoryPeriods(settings);
    const chain = [...historyPeriods, anchorDate];
    const chainBalances = new Array(chain.length);
    chainBalances[chain.length - 1] = anchorBalance;
    for (let i = chain.length - 1; i > 0; i--) {
      const p = chain[i];
      const prev = chain[i - 1];
      const rate = rateAt(schedule, p);
      const usage = usageInWindow(prev, p);
      chainBalances[i - 1] = chainBalances[i] - rate + usage;
    }
    historyPeriods.forEach((p, idx) => {
      chartData.push({
        dateObj: p,
        date: fmtISO(p),
        logged: chainBalances[idx],
        projected: null,
      });
    });

    let balance = anchorBalance;
    let prevDate = anchorDate;

    chartData.push({
      dateObj: prevDate,
      date: fmtISO(prevDate),
      logged: balance,
      projected: prevDate.getTime() >= todayTime ? balance : null,
    });

    let currentBalance = anchorBalance;
    let currentBalanceDate = prevDate;
    let accruedThisYear = 0;
    const year = today.getUTCFullYear();

    // history periods also count toward "accrued this year"
    historyPeriods.forEach((p) => {
      if (p.getUTCFullYear() === year) accruedThisYear += rateAt(schedule, p);
    });

    future.forEach((p) => {
      const rate = rateAt(schedule, p);
      balance = Math.min(balance + rate, settings.ptoCap);
      const isPast = p.getTime() <= todayTime;

      if (isPast && p.getUTCFullYear() === year) accruedThisYear += rate;

      if (isPast) {
        balance -= usageInWindow(prevDate, p);
      } else if (p.getUTCFullYear() >= settings.planStartYear) {
        const ppy = periodsPerYear[p.getUTCFullYear()] || 1;
        balance -= settings.annualUsagePlan / ppy;
      }

      chartData.push({
        dateObj: p,
        date: fmtISO(p),
        logged: isPast ? balance : null,
        projected: !isPast ? balance : null,
      });

      if (isPast) {
        currentBalance = balance;
        currentBalanceDate = p;
      }
      prevDate = p;
    });

    // bridge point so the two line segments connect visually
    const bridgeIdx = chartData.findIndex((pt) => pt.projected !== null);
    if (bridgeIdx > 0) {
      chartData[bridgeIdx - 1].projected = chartData[bridgeIdx - 1].logged;
    }

    // subtract any logged entries dated after "currentBalanceDate" but on/before today
    currentBalance -= usageInWindow(currentBalanceDate, today);

    const usedThisYear = sortedEntries
      .filter((e) => toUTC(e.date).getUTCFullYear() === year)
      .reduce((sum, e) => sum + Number(e.hours || 0), 0);
    const planThisYear = year >= settings.planStartYear ? settings.annualUsagePlan : 0;

    const nextPeriod = future.find((p) => p.getTime() > todayTime);
    const currentRate = rateAt(schedule, today);
    const nextRate = nextPeriod ? rateAt(schedule, nextPeriod) : currentRate;

    const finalProjected = chartData[chartData.length - 1];

    return {
      chartData,
      currentBalance,
      accruedThisYear,
      usedThisYear,
      planThisYear,
      remainingPlanThisYear: planThisYear - usedThisYear,
      nextPeriod,
      currentRate,
      nextRate,
      endBalance: finalProjected ? (finalProjected.projected ?? finalProjected.logged) : currentBalance,
      endDate: settings.projectionEndDate,
      isAtCap: currentBalance >= settings.ptoCap - 0.005,
    };
  }, [settings, entries, rateChanges, today]);
}

// ---------------------------------------------------------------------------
// Small presentational bits
// ---------------------------------------------------------------------------
function Stat({ label, value, suffix, tone }) {
  const toneColor =
    tone === "positive" ? COLOR.positive : tone === "negative" ? COLOR.negative : COLOR.textPrimary;
  return (
    <div
      className="flex-1 min-w-[140px] px-4 py-3"
      style={{ borderLeft: `2px solid ${COLOR.rule}` }}
    >
      <div
        className="text-[10px] tracking-[0.14em] uppercase mb-1"
        style={{ color: COLOR.textFaint, fontFamily: FONT_BODY }}
      >
        {label}
      </div>
      <div style={{ fontFamily: FONT_MONO, color: toneColor }} className="text-xl sm:text-2xl tabular-nums">
        {value}
        {suffix && (
          <span className="text-xs ml-1" style={{ color: COLOR.textFaint }}>
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  const val = payload[0]?.value ?? payload[1]?.value;
  const isProjected = payload[0]?.dataKey === "projected" && payload[0]?.value != null;
  if (val == null) return null;
  return (
    <div
      style={{
        background: COLOR.surfaceRaised,
        border: `1px solid ${COLOR.rule}`,
        fontFamily: FONT_MONO,
        color: COLOR.textPrimary,
      }}
      className="px-3 py-2 text-xs"
    >
      <div style={{ color: COLOR.textFaint }} className="mb-1">
        {fmtShort(toUTC(label))}
      </div>
      <div className="tabular-nums">
        {Number(val).toFixed(2)} hrs
        {isProjected && (
          <span style={{ color: COLOR.goldDim }} className="ml-1">
            (plan)
          </span>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------
export default function PTODashboard() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [entries, setEntries] = useState([]);
  const [rateChanges, setRateChanges] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [logMode, setLogMode] = useState("single"); // "single" | "range"
  const [formDate, setFormDate] = useState(fmtISO(new Date()));
  const [formHours, setFormHours] = useState("8");
  const [formNote, setFormNote] = useState("");
  const [rangeStart, setRangeStart] = useState(fmtISO(new Date()));
  const [rangeEnd, setRangeEnd] = useState(fmtISO(new Date()));
  const [rangeHours, setRangeHours] = useState("8");
  const [onlyWorkDays, setOnlyWorkDays] = useState(true);
  const [rangeNote, setRangeNote] = useState("");
  const [rateFormDate, setRateFormDate] = useState(fmtISO(new Date()));
  const [rateFormValue, setRateFormValue] = useState("");
  const [saveState, setSaveState] = useState("idle"); // idle | saving | error

  const today = useMemo(() => {
    const n = new Date();
    return new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()));
  }, []);

  // ---- load persisted state -------------------------------------------------
  useEffect(() => {
    (async () => {
      try {
        const s = await window.storage.get("pto-settings", false);
        if (s?.value) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(s.value) });
      } catch (e) {
        /* no saved settings yet */
      }
      try {
        const e = await window.storage.get("pto-entries", false);
        if (e?.value) setEntries(JSON.parse(e.value));
      } catch (e) {
        /* no saved entries yet */
      }
      try {
        const r = await window.storage.get("pto-rate-changes", false);
        if (r?.value) setRateChanges(JSON.parse(r.value));
      } catch (e) {
        /* no saved rate changes yet */
      }
      setLoaded(true);
    })();
  }, []);

  // ---- persist on change ------------------------------------------------
  useEffect(() => {
    if (!loaded) return;
    (async () => {
      try {
        setSaveState("saving");
        await window.storage.set("pto-settings", JSON.stringify(settings), false);
        setSaveState("idle");
      } catch (e) {
        setSaveState("error");
      }
    })();
  }, [settings, loaded]);

  useEffect(() => {
    if (!loaded) return;
    (async () => {
      try {
        setSaveState("saving");
        await window.storage.set("pto-entries", JSON.stringify(entries), false);
        setSaveState("idle");
      } catch (e) {
        setSaveState("error");
      }
    })();
  }, [entries, loaded]);

  useEffect(() => {
    if (!loaded) return;
    (async () => {
      try {
        setSaveState("saving");
        await window.storage.set("pto-rate-changes", JSON.stringify(rateChanges), false);
        setSaveState("idle");
      } catch (e) {
        setSaveState("error");
      }
    })();
  }, [rateChanges, loaded]);

  const projection = useProjection(settings, entries, rateChanges, today);

  const addEntry = useCallback(() => {
    const hrs = Number(formHours);
    if (!formDate || !hrs || hrs <= 0) return;
    setEntries((prev) => [
      ...prev,
      { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date: formDate, hours: hrs, note: formNote.trim() },
    ]);
    setFormHours("8");
    setFormNote("");
  }, [formDate, formHours, formNote]);

  const rangeDates = useMemo(() => {
    if (!rangeStart || !rangeEnd) return [];
    const start = toUTC(rangeStart);
    const end = toUTC(rangeEnd);
    if (end.getTime() < start.getTime()) return [];
    const dates = [];
    let d = start;
    while (d.getTime() <= end.getTime()) {
      if (!(onlyWorkDays && !isRotationWorkDay(d, settings))) dates.push(d);
      d = addDaysUTC(d, 1);
    }
    return dates;
  }, [rangeStart, rangeEnd, onlyWorkDays, settings]);

  const addRangeEntries = useCallback(() => {
    const hrs = Number(rangeHours);
    if (!rangeDates.length || !hrs || hrs <= 0) return;
    const note = rangeNote.trim();
    setEntries((prev) => [
      ...prev,
      ...rangeDates.map((d, i) => ({
        id: `${Date.now()}-${i}-${Math.random().toString(36).slice(2, 7)}`,
        date: fmtISO(d),
        hours: hrs,
        note,
      })),
    ]);
    setRangeNote("");
  }, [rangeDates, rangeHours, rangeNote]);

  const removeEntry = useCallback((id) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const addRateChange = useCallback(() => {
    const rate = Number(rateFormValue);
    if (!rateFormDate || !rateFormValue || isNaN(rate) || rate < 0) return;
    setRateChanges((prev) => [
      ...prev,
      { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, effectiveDate: rateFormDate, rate },
    ]);
    setRateFormValue("");
  }, [rateFormDate, rateFormValue]);

  const removeRateChange = useCallback((id) => {
    setRateChanges((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const fileInputRef = useRef(null);
  const [importMsg, setImportMsg] = useState("");

  const exportBackup = useCallback(() => {
    const payload = { app: "pto-tracker", exportedAt: fmtISO(new Date()), settings, entries, rateChanges };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pto-tracker-backup-${fmtISO(new Date())}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [settings, entries, rateChanges]);

  const triggerImport = useCallback(() => {
    if (fileInputRef.current) fileInputRef.current.click();
  }, []);

  const handleImportFile = useCallback(
    (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          if (!data || typeof data !== "object" || !data.settings || !Array.isArray(data.entries)) {
            setImportMsg("That file doesn't look like a PTO Tracker backup.");
            return;
          }
          const proceed = window.confirm(
            `Import backup from ${data.exportedAt || "unknown date"}? This replaces your current settings, ${entries.length} logged entr${entries.length === 1 ? "y" : "ies"}, and ${rateChanges.length} rate change${rateChanges.length === 1 ? "" : "s"} currently stored here.`
          );
          if (!proceed) return;
          setSettings({ ...DEFAULT_SETTINGS, ...data.settings });
          setEntries(Array.isArray(data.entries) ? data.entries : []);
          setRateChanges(Array.isArray(data.rateChanges) ? data.rateChanges : []);
          setImportMsg("Backup imported.");
        } catch (err) {
          setImportMsg("Couldn't read that file — is it a PTO Tracker backup JSON?");
        }
      };
      reader.readAsText(file);
    },
    [entries.length, rateChanges.length]
  );

  useEffect(() => {
    if (!importMsg) return;
    const t = setTimeout(() => setImportMsg(""), 4000);
    return () => clearTimeout(t);
  }, [importMsg]);

  const sortedRateChanges = useMemo(
    () => [...rateChanges].sort((a, b) => (a.effectiveDate < b.effectiveDate ? 1 : -1)),
    [rateChanges]
  );

  const sortedEntries = useMemo(
    () => [...entries].sort((a, b) => (a.date < b.date ? 1 : -1)),
    [entries]
  );

  const usagePct = projection.planThisYear
    ? Math.min(100, (projection.usedThisYear / projection.planThisYear) * 100)
    : 0;

  return (
    <div
      className="w-full min-h-screen"
      style={{ background: COLOR.bg, fontFamily: FONT_BODY, color: COLOR.textPrimary }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Inter:wght@400;500;600&display=swap');
        .tabular-nums { font-variant-numeric: tabular-nums; }
        input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(0.6); cursor: pointer; }
        ::selection { background: ${COLOR.goldSoft}; }
      `}</style>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* ---------------- Header ---------------- */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <Clock3 size={18} style={{ color: COLOR.gold }} />
            <div>
              <div
                className="text-[10px] tracking-[0.22em] uppercase"
                style={{ color: COLOR.textFaint }}
              >
                Duty Log
              </div>
              <h1
                className="text-lg sm:text-xl uppercase tracking-wide leading-none"
                style={{ fontFamily: FONT_DISPLAY, fontWeight: 600 }}
              >
                PTO Tracker
              </h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="application/json"
              onChange={handleImportFile}
              className="hidden"
            />
            <button
              onClick={exportBackup}
              className="flex items-center gap-1.5 text-xs px-3 py-2 transition-colors"
              style={{ color: COLOR.textMuted, border: `1px solid ${COLOR.rule}`, background: "transparent" }}
            >
              <Download size={13} />
              Export
            </button>
            <button
              onClick={triggerImport}
              className="flex items-center gap-1.5 text-xs px-3 py-2 transition-colors"
              style={{ color: COLOR.textMuted, border: `1px solid ${COLOR.rule}`, background: "transparent" }}
            >
              <Upload size={13} />
              Import
            </button>
            <button
              onClick={() => setShowSettings((s) => !s)}
              className="flex items-center gap-1.5 text-xs px-3 py-2 transition-colors"
              style={{
                color: showSettings ? COLOR.gold : COLOR.textMuted,
                border: `1px solid ${COLOR.rule}`,
                background: showSettings ? COLOR.goldSoft : "transparent",
              }}
            >
              <Settings2 size={13} />
              Settings
            </button>
          </div>
        </div>
        {importMsg && (
          <div
            className="text-xs -mt-4 mb-4"
            style={{
              color: importMsg.startsWith("Backup imported") ? COLOR.positive : COLOR.negative,
              fontFamily: FONT_MONO,
            }}
          >
            {importMsg}
          </div>
        )}

        {/* ---------------- Settings panel ---------------- */}
        {showSettings && (
          <div
            className="mb-6 p-4 grid grid-cols-2 sm:grid-cols-3 gap-4"
            style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
          >
            <SettingField
              label="Starting balance (hrs)"
              value={settings.startingBalance}
              onChange={(v) => setSettings((s) => ({ ...s, startingBalance: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Base accrual / pay period (hrs)"
              value={settings.accrualRate}
              onChange={(v) => setSettings((s) => ({ ...s, accrualRate: Number(v) }))}
              type="number"
            />
            <SettingField
              label="As-of paycheck date"
              value={settings.lastPaycheckDate}
              onChange={(v) => setSettings((s) => ({ ...s, lastPaycheckDate: v }))}
              type="date"
            />
            <SettingField
              label="History start date"
              value={settings.historyStartDate}
              onChange={(v) => setSettings((s) => ({ ...s, historyStartDate: v }))}
              type="date"
            />
            <SettingField
              label="Pay frequency (days)"
              value={settings.payFrequencyDays}
              onChange={(v) => setSettings((s) => ({ ...s, payFrequencyDays: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Planned annual usage (hrs)"
              value={settings.annualUsagePlan}
              onChange={(v) => setSettings((s) => ({ ...s, annualUsagePlan: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Plan starts (year)"
              value={settings.planStartYear}
              onChange={(v) => setSettings((s) => ({ ...s, planStartYear: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Hours per work day"
              value={settings.workDayHours}
              onChange={(v) => setSettings((s) => ({ ...s, workDayHours: Number(v) }))}
              type="number"
            />
            <SettingField
              label="PTO cap (hrs)"
              value={settings.ptoCap}
              onChange={(v) => setSettings((s) => ({ ...s, ptoCap: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Rotation anchor (1st day on)"
              value={settings.rotationAnchorDate}
              onChange={(v) => setSettings((s) => ({ ...s, rotationAnchorDate: v }))}
              type="date"
            />
            <SettingField
              label="Days on (block 1)"
              value={settings.rotationOn1}
              onChange={(v) => setSettings((s) => ({ ...s, rotationOn1: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Days off (block 1)"
              value={settings.rotationOff1}
              onChange={(v) => setSettings((s) => ({ ...s, rotationOff1: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Days on (block 2)"
              value={settings.rotationOn2}
              onChange={(v) => setSettings((s) => ({ ...s, rotationOn2: Number(v) }))}
              type="number"
            />
            <SettingField
              label="Days off (block 2)"
              value={settings.rotationOff2}
              onChange={(v) => setSettings((s) => ({ ...s, rotationOff2: Number(v) }))}
              type="number"
            />
            <div className="col-span-2 sm:col-span-3">
              <SettingField
                label="Project balance through"
                value={settings.projectionEndDate}
                onChange={(v) => setSettings((s) => ({ ...s, projectionEndDate: v }))}
                type="date"
              />
            </div>
          </div>
        )}

        {/* ---------------- Balance readout ---------------- */}
        <div
          className="mb-6 px-5 sm:px-6 py-6"
          style={{
            background: COLOR.surface,
            borderTop: `2px solid ${COLOR.gold}`,
            borderBottom: `2px solid ${COLOR.gold}`,
          }}
        >
          <div
            className="text-[10px] tracking-[0.2em] uppercase mb-1"
            style={{ color: COLOR.textFaint }}
          >
            Current Balance · as of {fmtShort(today)}
          </div>
          <div className="flex items-baseline flex-wrap gap-x-4 gap-y-1">
            <div
              className="tabular-nums leading-none"
              style={{ fontFamily: FONT_MONO, fontSize: "clamp(2.5rem, 8vw, 4rem)", color: COLOR.textPrimary }}
            >
              {projection.currentBalance.toFixed(2)}
              <span className="text-lg sm:text-xl ml-2" style={{ color: COLOR.goldDim }}>
                HRS
              </span>
            </div>
            <div
              className="tabular-nums leading-none pb-1"
              style={{ fontFamily: FONT_MONO, fontSize: "clamp(1.1rem, 3vw, 1.5rem)", color: COLOR.gold }}
            >
              ≈ {(projection.currentBalance / settings.workDayHours).toFixed(1)}
              <span className="text-sm ml-1.5" style={{ color: COLOR.goldDim }}>
                DAYS OFF
              </span>
            </div>
          </div>
          <div className="mt-2 text-xs" style={{ color: COLOR.textMuted, fontFamily: FONT_MONO }}>
            +{projection.currentRate.toFixed(2)} hrs / period · based on {settings.workDayHours}-hr work day ·{" "}
            {projection.nextPeriod ? (
              <>
                next accrual {fmtShort(projection.nextPeriod)}
                {projection.nextRate !== projection.currentRate && (
                  <span style={{ color: COLOR.gold }}> (rate changes to {projection.nextRate.toFixed(2)})</span>
                )}
              </>
            ) : (
              <>no further accruals scheduled</>
            )}
          </div>
          <div className="mt-3">
            <div className="flex items-center justify-between text-[10px] mb-1" style={{ fontFamily: FONT_MONO, color: COLOR.textFaint }}>
              <span>CAP {settings.ptoCap.toFixed(0)} HRS</span>
              <span style={{ color: projection.isAtCap ? COLOR.negative : COLOR.textFaint }}>
                {Math.min(100, (projection.currentBalance / settings.ptoCap) * 100).toFixed(0)}%
              </span>
            </div>
            <div className="h-1 w-full" style={{ background: COLOR.ruleFaint }}>
              <div
                className="h-1"
                style={{
                  width: `${Math.min(100, (projection.currentBalance / settings.ptoCap) * 100)}%`,
                  background: projection.isAtCap ? COLOR.negative : COLOR.gold,
                  transition: "width 300ms ease",
                }}
              />
            </div>
            {projection.isAtCap && (
              <div className="mt-1.5 text-xs" style={{ color: COLOR.negative, fontFamily: FONT_MONO }}>
                At cap — further accrual is forfeited until you use hours
              </div>
            )}
          </div>
        </div>

        {/* ---------------- Stat strip ---------------- */}
        <div
          className="flex flex-wrap mb-6"
          style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
        >
          <Stat
            label={`Accrued in ${today.getUTCFullYear()}`}
            value={`+${projection.accruedThisYear.toFixed(2)}`}
            tone="positive"
          />
          <Stat
            label={`Used in ${today.getUTCFullYear()}`}
            value={projection.usedThisYear ? `-${projection.usedThisYear.toFixed(2)}` : "0.00"}
            tone={projection.usedThisYear ? "negative" : undefined}
          />
          <Stat
            label={projection.planThisYear ? "Remaining plan" : "Usage plan"}
            value={
              projection.planThisYear
                ? projection.remainingPlanThisYear.toFixed(2)
                : `starts ${settings.planStartYear}`
            }
          />
          <Stat
            label={`Projected · ${settings.projectionEndDate.slice(0, 4)}`}
            value={projection.endBalance.toFixed(2)}
            suffix={`≈${(projection.endBalance / settings.workDayHours).toFixed(1)}d`}
          />
        </div>

        {projection.planThisYear > 0 && (
          <div className="mb-8 -mt-4">
            <div className="h-1 w-full" style={{ background: COLOR.ruleFaint }}>
              <div
                className="h-1"
                style={{ width: `${usagePct}%`, background: COLOR.gold, transition: "width 300ms ease" }}
              />
            </div>
            <div className="text-[10px] mt-1" style={{ color: COLOR.textFaint, fontFamily: FONT_MONO }}>
              {projection.usedThisYear.toFixed(2)} / {projection.planThisYear.toFixed(0)} planned hrs used this
              year
            </div>
          </div>
        )}

        {/* ---------------- Chart ---------------- */}
        <div className="mb-8">
          <div
            className="text-[10px] tracking-[0.2em] uppercase mb-1"
            style={{ color: COLOR.textFaint }}
          >
            Balance Trajectory — logged vs. plan
          </div>
          <div className="text-[10px] mb-3" style={{ color: COLOR.textFaint, fontFamily: FONT_MONO }}>
            {settings.historyStartDate} → {settings.lastPaycheckDate} is reconstructed backward from your as-of
            balance (assumes no cap was hit); everything after is tracked forward. If you're on pace to use your
            full {settings.annualUsagePlan}-hr annual plan every period, the projected line plateaus a bit below
            the {settings.ptoCap}-hr cap (usage is assumed to land the same period as accrual) — the balance only
            sits exactly at {settings.ptoCap} if you go a stretch without using hours.
          </div>
          <div
            style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
            className="p-3 sm:p-4"
          >
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={projection.chartData} margin={{ top: 8, right: 12, bottom: 0, left: -12 }}>
                <CartesianGrid stroke={COLOR.ruleFaint} vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fill: COLOR.textFaint, fontSize: 10, fontFamily: FONT_MONO }}
                  tickFormatter={(d) => toUTC(d).getUTCFullYear()}
                  interval={Math.max(0, Math.floor(projection.chartData.length / 8))}
                  axisLine={{ stroke: COLOR.rule }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: COLOR.textFaint, fontSize: 10, fontFamily: FONT_MONO }}
                  axisLine={false}
                  tickLine={false}
                  width={44}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine
                  x={fmtISO(today)}
                  stroke={COLOR.gold}
                  strokeDasharray="2 3"
                  strokeOpacity={0.6}
                />
                <ReferenceLine
                  y={settings.ptoCap}
                  stroke={COLOR.negative}
                  strokeDasharray="2 3"
                  strokeOpacity={0.55}
                  label={{
                    value: `CAP ${settings.ptoCap}`,
                    position: "insideTopLeft",
                    fill: COLOR.negative,
                    fontSize: 10,
                    fontFamily: FONT_MONO,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="logged"
                  stroke={COLOR.textPrimary}
                  strokeWidth={2}
                  dot={false}
                  connectNulls={false}
                  isAnimationActive={false}
                />
                <Line
                  type="monotone"
                  dataKey="projected"
                  stroke={COLOR.gold}
                  strokeWidth={2}
                  strokeDasharray="4 3"
                  dot={false}
                  connectNulls={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2 text-[10px]" style={{ color: COLOR.textFaint, fontFamily: FONT_MONO }}>
              <span className="flex items-center gap-1.5">
                <span className="inline-block w-3 h-[2px]" style={{ background: COLOR.textPrimary }} /> logged
              </span>
              <span className="flex items-center gap-1.5">
                <span
                  className="inline-block w-3 h-[2px]"
                  style={{ background: COLOR.gold, borderTop: `2px dashed ${COLOR.gold}` }}
                />
                planned
              </span>
            </div>
          </div>
        </div>

        {/* ---------------- Log time off ---------------- */}
        <div className="flex items-center justify-between mb-3">
          <div className="text-[10px] tracking-[0.2em] uppercase" style={{ color: COLOR.textFaint }}>
            Log Time Off
          </div>
          <div className="flex" style={{ border: `1px solid ${COLOR.rule}` }}>
            <button
              onClick={() => setLogMode("single")}
              className="text-[11px] px-3 py-1 transition-colors"
              style={{
                background: logMode === "single" ? COLOR.goldSoft : "transparent",
                color: logMode === "single" ? COLOR.gold : COLOR.textMuted,
                fontFamily: FONT_MONO,
              }}
            >
              Single Day
            </button>
            <button
              onClick={() => setLogMode("range")}
              className="text-[11px] px-3 py-1 transition-colors"
              style={{
                background: logMode === "range" ? COLOR.goldSoft : "transparent",
                color: logMode === "range" ? COLOR.gold : COLOR.textMuted,
                fontFamily: FONT_MONO,
                borderLeft: `1px solid ${COLOR.rule}`,
              }}
            >
              Date Range
            </button>
          </div>
        </div>

        {logMode === "single" ? (
          <div
            className="mb-3 p-3 sm:p-4 flex flex-wrap gap-3 items-end"
            style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
          >
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
              Date
            </label>
            <input
              type="date"
              value={formDate}
              onChange={(e) => setFormDate(e.target.value)}
              className="px-2 py-1.5 text-sm outline-none"
              style={{
                background: COLOR.surfaceRaised,
                border: `1px solid ${COLOR.rule}`,
                color: COLOR.textPrimary,
                fontFamily: FONT_MONO,
              }}
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
              Hours
            </label>
            <input
              type="number"
              min="0.25"
              step="0.25"
              value={formHours}
              onChange={(e) => setFormHours(e.target.value)}
              className="px-2 py-1.5 text-sm outline-none w-24 tabular-nums"
              style={{
                background: COLOR.surfaceRaised,
                border: `1px solid ${COLOR.rule}`,
                color: COLOR.textPrimary,
                fontFamily: FONT_MONO,
              }}
            />
          </div>
          <div className="flex flex-col gap-1 flex-1 min-w-[160px]">
            <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
              Note (optional)
            </label>
            <input
              type="text"
              placeholder="e.g. day off"
              value={formNote}
              onChange={(e) => setFormNote(e.target.value)}
              className="px-2 py-1.5 text-sm outline-none w-full"
              style={{
                background: COLOR.surfaceRaised,
                border: `1px solid ${COLOR.rule}`,
                color: COLOR.textPrimary,
                fontFamily: FONT_BODY,
              }}
            />
          </div>
          <button
            onClick={addEntry}
            className="flex items-center gap-1.5 px-4 py-1.5 text-sm font-medium transition-opacity hover:opacity-90"
            style={{ background: COLOR.gold, color: "#1A1400" }}
          >
            <Plus size={14} strokeWidth={2.5} />
            Log
          </button>
          </div>
        ) : (
          <div
            className="mb-3 p-3 sm:p-4 flex flex-wrap gap-3 items-end"
            style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
          >
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
                From
              </label>
              <input
                type="date"
                value={rangeStart}
                onChange={(e) => setRangeStart(e.target.value)}
                className="px-2 py-1.5 text-sm outline-none"
                style={{
                  background: COLOR.surfaceRaised,
                  border: `1px solid ${COLOR.rule}`,
                  color: COLOR.textPrimary,
                  fontFamily: FONT_MONO,
                }}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
                To
              </label>
              <input
                type="date"
                value={rangeEnd}
                onChange={(e) => setRangeEnd(e.target.value)}
                className="px-2 py-1.5 text-sm outline-none"
                style={{
                  background: COLOR.surfaceRaised,
                  border: `1px solid ${COLOR.rule}`,
                  color: COLOR.textPrimary,
                  fontFamily: FONT_MONO,
                }}
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
                Hours / day
              </label>
              <input
                type="number"
                min="0.25"
                step="0.25"
                value={rangeHours}
                onChange={(e) => setRangeHours(e.target.value)}
                className="px-2 py-1.5 text-sm outline-none w-24 tabular-nums"
                style={{
                  background: COLOR.surfaceRaised,
                  border: `1px solid ${COLOR.rule}`,
                  color: COLOR.textPrimary,
                  fontFamily: FONT_MONO,
                }}
              />
            </div>
            <div className="flex flex-col gap-1 flex-1 min-w-[160px]">
              <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
                Note (optional)
              </label>
              <input
                type="text"
                placeholder="e.g. week at the cabin"
                value={rangeNote}
                onChange={(e) => setRangeNote(e.target.value)}
                className="px-2 py-1.5 text-sm outline-none w-full"
                style={{
                  background: COLOR.surfaceRaised,
                  border: `1px solid ${COLOR.rule}`,
                  color: COLOR.textPrimary,
                  fontFamily: FONT_BODY,
                }}
              />
            </div>
            <label
              className="flex items-center gap-1.5 text-xs pb-1.5 cursor-pointer select-none"
              style={{ color: COLOR.textMuted, fontFamily: FONT_BODY }}
            >
              <input
                type="checkbox"
                checked={onlyWorkDays}
                onChange={(e) => setOnlyWorkDays(e.target.checked)}
              />
              Only my scheduled work days (rotation)
            </label>
            <button
              onClick={addRangeEntries}
              disabled={!rangeDates.length}
              className="flex items-center gap-1.5 px-4 py-1.5 text-sm font-medium transition-opacity hover:opacity-90"
              style={{
                background: COLOR.gold,
                color: "#1A1400",
                opacity: rangeDates.length ? 1 : 0.4,
                cursor: rangeDates.length ? "pointer" : "not-allowed",
              }}
            >
              <Plus size={14} strokeWidth={2.5} />
              Log {rangeDates.length || ""} Day{rangeDates.length === 1 ? "" : "s"}
            </button>
            <div className="text-[10px] w-full" style={{ color: COLOR.textFaint, fontFamily: FONT_MONO }}>
              {rangeDates.length > 0
                ? `= ${(rangeDates.length * Number(rangeHours || 0)).toFixed(2)} hrs total across ${rangeDates.length} day${rangeDates.length === 1 ? "" : "s"}`
                : "pick a valid range to preview total hours"}
            </div>
            <div className="text-[10px] w-full" style={{ color: COLOR.textFaint, fontFamily: FONT_BODY }}>
              Rotation: {settings.rotationOn1} on / {settings.rotationOff1} off / {settings.rotationOn2} on /{" "}
              {settings.rotationOff2} off, anchored to {settings.rotationAnchorDate} (edit in Settings if that
              date wasn't day one of an on-block).
            </div>
          </div>
        )}

        {/* ---------------- Entry log ---------------- */}
        {sortedEntries.length > 0 && (
          <div style={{ border: `1px solid ${COLOR.rule}` }} className="mb-4">
            {sortedEntries.map((e, i) => (
              <div
                key={e.id}
                className="flex items-center gap-3 px-3 sm:px-4 py-2.5 text-sm"
                style={{
                  background: i % 2 === 0 ? COLOR.surface : COLOR.surfaceRaised,
                  borderLeft: `2px solid ${COLOR.gold}`,
                }}
              >
                <span
                  className="tabular-nums w-20 shrink-0"
                  style={{ fontFamily: FONT_MONO, color: COLOR.textMuted }}
                >
                  {fmtChip(toUTC(e.date))}
                </span>
                <span
                  className="tabular-nums w-16 shrink-0"
                  style={{ fontFamily: FONT_MONO, color: COLOR.negative }}
                >
                  -{Number(e.hours).toFixed(2)}
                </span>
                <span className="flex-1 truncate" style={{ color: e.note ? COLOR.textPrimary : COLOR.textFaint }}>
                  {e.note || "—"}
                </span>
                <button
                  onClick={() => removeEntry(e.id)}
                  className="shrink-0 p-1 transition-colors"
                  style={{ color: COLOR.textFaint }}
                  onMouseEnter={(ev) => (ev.currentTarget.style.color = COLOR.negative)}
                  onMouseLeave={(ev) => (ev.currentTarget.style.color = COLOR.textFaint)}
                  aria-label="Delete entry"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ---------------- Accrual rate schedule ---------------- */}
        <div
          className="text-[10px] tracking-[0.2em] uppercase mb-3"
          style={{ color: COLOR.textFaint }}
        >
          Accrual Rate Schedule
        </div>
        <div
          className="mb-3 p-3 sm:p-4 flex flex-wrap gap-3 items-end"
          style={{ background: COLOR.surface, border: `1px solid ${COLOR.rule}` }}
        >
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
              Effective date
            </label>
            <input
              type="date"
              value={rateFormDate}
              onChange={(e) => setRateFormDate(e.target.value)}
              className="px-2 py-1.5 text-sm outline-none"
              style={{
                background: COLOR.surfaceRaised,
                border: `1px solid ${COLOR.rule}`,
                color: COLOR.textPrimary,
                fontFamily: FONT_MONO,
              }}
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
              New rate (hrs/period)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 12.31"
              value={rateFormValue}
              onChange={(e) => setRateFormValue(e.target.value)}
              className="px-2 py-1.5 text-sm outline-none w-32 tabular-nums"
              style={{
                background: COLOR.surfaceRaised,
                border: `1px solid ${COLOR.rule}`,
                color: COLOR.textPrimary,
                fontFamily: FONT_MONO,
              }}
            />
          </div>
          <button
            onClick={addRateChange}
            className="flex items-center gap-1.5 px-4 py-1.5 text-sm font-medium transition-opacity hover:opacity-90"
            style={{ background: COLOR.gold, color: "#1A1400" }}
          >
            <Plus size={14} strokeWidth={2.5} />
            Add Change
          </button>
          <div className="text-[10px] w-full sm:w-auto sm:ml-auto" style={{ color: COLOR.textFaint, fontFamily: FONT_BODY }}>
            Applies from the effective date onward — past and future accruals recalculate automatically.
          </div>
        </div>

        {sortedRateChanges.length > 0 && (
          <div style={{ border: `1px solid ${COLOR.rule}` }} className="mb-8">
            {sortedRateChanges.map((r, i) => (
              <div
                key={r.id}
                className="flex items-center gap-3 px-3 sm:px-4 py-2.5 text-sm"
                style={{
                  background: i % 2 === 0 ? COLOR.surface : COLOR.surfaceRaised,
                  borderLeft: `2px solid ${COLOR.gold}`,
                }}
              >
                <span
                  className="tabular-nums w-20 shrink-0"
                  style={{ fontFamily: FONT_MONO, color: COLOR.textMuted }}
                >
                  {fmtChip(toUTC(r.effectiveDate))}
                </span>
                <span
                  className="tabular-nums w-28 shrink-0"
                  style={{ fontFamily: FONT_MONO, color: COLOR.positive }}
                >
                  {Number(r.rate).toFixed(2)} hrs/pd
                </span>
                <span className="flex-1 truncate" style={{ color: COLOR.textFaint }}>
                  effective onward
                </span>
                <button
                  onClick={() => removeRateChange(r.id)}
                  className="shrink-0 p-1 transition-colors"
                  style={{ color: COLOR.textFaint }}
                  onMouseEnter={(ev) => (ev.currentTarget.style.color = COLOR.negative)}
                  onMouseLeave={(ev) => (ev.currentTarget.style.color = COLOR.textFaint)}
                  aria-label="Delete rate change"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        )}

        <div
          className="text-[10px] flex items-center justify-between"
          style={{ color: COLOR.textFaint, fontFamily: FONT_MONO }}
        >
          <span>
            {entries.length} entr{entries.length === 1 ? "y" : "ies"} logged · saved automatically to your
            Claude account · hit Export above for a manual backup
          </span>
          <span style={{ opacity: saveState === "saving" ? 1 : 0, transition: "opacity 200ms" }}>saving…</span>
        </div>
      </div>
    </div>
  );
}

function SettingField({ label, value, onChange, type }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[10px] uppercase tracking-wide" style={{ color: COLOR.textFaint }}>
        {label}
      </label>
      <input
        type={type}
        value={value}
        step={type === "number" ? "any" : undefined}
        onChange={(e) => onChange(e.target.value)}
        className="px-2 py-1.5 text-sm outline-none"
        style={{
          background: COLOR.surfaceRaised,
          border: `1px solid ${COLOR.rule}`,
          color: COLOR.textPrimary,
          fontFamily: FONT_MONO,
        }}
      />
    </div>
  );
}
